import socket
import threading
from datetime import datetime

# Dictionary to store registered users and their passwords
users = {}

# Dictionary to store active chatrooms, their hosts, members, and pending requests
chatrooms = {}

# Dictionary to store event logs for each chatroom (messages, joins, leaves)
logs = {}

# Adds a timestamped message to the log of a specific chatroom
def log_event(room, message):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    logs[room].append(f"{timestamp} {message}")

# Function to handle incoming client requests (signup/login and joining/creating a room)
def handle_client(conn, addr):
    conn.send(b"Enter 'signup' or 'login' or '/quit':  (enter twice after selecting an option) ")

    while True:
        choice = conn.recv(1024).decode().strip()

        if choice == '/quit':
            # Handle user quitting the application
            conn.close()
            return

        if choice == 'signup':
            conn.send(b"Username: ")
            username = conn.recv(1024).decode().strip()
            conn.send(b"Password: ")
            password = conn.recv(1024).decode().strip()

            if username in users:
                # If username already exists, prompt the user to login instead
                conn.send(b"Username already exists. Try logging in with a different username.\nEnter 'signup' or 'login' or '/quit':   (enter twice after selecting an option) ")
            else:
                # If the username is new, register the user
                users[username] = password
                conn.send(b"Signup successful.\n")
                break

        elif choice == 'login':
            conn.send(b"Username: ")
            username = conn.recv(1024).decode().strip()
            conn.send(b"Password: ")
            password = conn.recv(1024).decode().strip()

            if users.get(username) == password:
                # If login credentials are correct, login the user
                conn.send(b"Login successful.\n")
                break
            else:
                # If login fails, ask user to try again
                conn.send(b"Invalid username or password, try again.\nEnter 'signup' or 'login' or '/quit': ")

        else:
            # If the user enters anything other than 'signup', 'login', or '/quit'
            conn.send(b"Invalid choice. Enter 'signup' or 'login' or '/quit':  (enter twice after selecting an option) ")

    conn.send(b"Enter 'create' to make chatroom or 'join' to enter one: (enter twice after selecting an option)  ")
    action = conn.recv(1024).decode().strip()

    if action == 'create':
        conn.send(b"Enter room name: ")
        room = conn.recv(1024).decode().strip()

        # Create a new chatroom with the user as the host
        chatrooms[room] = {'host': username, 'clients': {username: conn}, 'pending': {}, 'names': {conn: username}}
        logs[room] = []

        conn.send(f"Chatroom '{room}' created. You are the host.\n".encode())

        # Provide host instructions on commands they can use
        conn.send(b"""\nHost Commands: you as a host can: 
=====================================================================================            
||               /kick <username>   - Remove a user from chat                      ||
||               /rename <old> <new> - Change someone's username                   ||
||               /terminate         - Close the chatroom for all                   ||
=====================================================================================
Type messages to broadcast to the room.\n""")

        log_event(room, f"Chatroom '{room}' created by {username}.")
        host_thread(conn, room, username)

    elif action == 'join':
        while True:
            conn.send(b"Enter room name to join: ")
            room = conn.recv(1024).decode().strip()

            if room not in chatrooms:
                # If the room doesn't exist, prompt to try again
                conn.send(b"Room doesn't exist.\n")
                continue

            if username in chatrooms[room]['clients'] or username in chatrooms[room]['pending']:
                # If the user is already in or waiting for the room
                conn.send(b"You are already in or waiting for this room.\n")
                continue

            # Send join request to the host of the room
            host_conn = chatrooms[room]['clients'][chatrooms[room]['host']]
            chatrooms[room]['pending'][username] = conn
            chatrooms[room]['names'][conn] = username

            host_conn.send(f"{username} wants to join {room}. Type yes or no to approve.\n".encode())
            conn.send(f"Request sent to host of '{room}'. Please wait until the host accepts you \n".encode())
            return

    else:
        # If the user enters anything other than 'create' or 'join'
        conn.send(b"Invalid action. Disconnecting.\n")
        conn.close()

# Runs on the host side; processes admin commands and chat messages
def host_thread(conn, room, username):
    while True:
        try:
            msg = conn.recv(1024).decode().strip()

            if msg.lower() == 'yes':
                # Host approves the first user in the pending list
                if chatrooms[room]['pending']:
                    new_user = list(chatrooms[room]['pending'].keys())[0]
                    new_conn = chatrooms[room]['pending'].pop(new_user)

                    chatrooms[room]['clients'][new_user] = new_conn
                    chatrooms[room]['names'][new_conn] = new_user
                    new_conn.send(f"Approved. You joined '{room}'.\n".encode())

                    log_event(room, f"{new_user} joined the chat.")
                    broadcast(room, f"{new_user} has joined the chat.\n", exclude=[new_user])
                    threading.Thread(target=chat_thread, args=(new_conn, room), daemon=True).start()

            elif msg.lower() == 'no':
                # Host denies a pending request
                if chatrooms[room]['pending']:
                    denied_user = list(chatrooms[room]['pending'].keys())[0]
                    denied_conn = chatrooms[room]['pending'].pop(denied_user)
                    denied_conn.send(b"Your request was denied.\nEnter 'join' to try another chatroom or '/quit': ")
                    del chatrooms[room]['names'][denied_conn]

            elif msg.startswith('/kick '):
                # Host removes a user from the room
                target = msg.split()[1]
                if target in chatrooms[room]['clients']:
                    target_conn = chatrooms[room]['clients'].pop(target)
                    log_event(room, f"{target} was kicked from the chat.")
                    broadcast(room, f"{target} has been kicked from the chatroom.\n", exclude=[target])
                    target_conn.send(b"You have been kicked from the chatroom.\n")
                    target_conn.close()
                    del chatrooms[room]['names'][target_conn]

            elif msg.startswith('/rename '):
                # Host renames a user if the new username isn't taken
                parts = msg.split()
                if len(parts) != 3:
                    conn.send(b"Usage: /rename <old_username> <new_username>\n")
                    continue

                old_name, new_name = parts[1], parts[2]
                if old_name not in chatrooms[room]['clients']:
                    conn.send(f"{old_name} is not in the chatroom.\n".encode())
                    continue
                if new_name in users:
                    conn.send(f"Username '{new_name}' already exists.\n".encode())
                    continue

                users[new_name] = users.pop(old_name)
                client_conn = chatrooms[room]['clients'].pop(old_name)
                chatrooms[room]['clients'][new_name] = client_conn
                chatrooms[room]['names'][client_conn] = new_name

                client_conn.send(f"Your username has been changed to {new_name} by the host.\n".encode())
                broadcast(room, f"{old_name} has been renamed to {new_name} by the host.\n", exclude=[new_name])
                log_event(room, f"{old_name} was renamed to {new_name} by the host.")

            elif msg == '/terminate':
                # Host decides to end the chatroom; log gets written to a file
                log_event(room, f"Chatroom '{room}' terminated by {username}.")
                for user, c in chatrooms[room]['clients'].items():
                    if user != username:
                        c.send(b"Chatroom terminated by host.\n")
                        c.close()

                with open(f"{room}_log.txt", "w") as f:
                    f.write("\n".join(logs[room]))

                del chatrooms[room]
                del logs[room]
                conn.send(b"Chatroom terminated.\n")
                conn.close()
                break

            else:
                # Host sends a regular message
                broadcast(room, msg, sender=username)
                log_event(room, f"{username}: {msg}")

        except:
            # If host disconnects unexpectedly
            conn.close()
            del chatrooms[room]['clients'][username]
            broadcast(room, f"{username} left the chat.\n")
            log_event(room, f"{username} left the chat.")
            break

# Runs for each non-host user who joins a chatroom
def chat_thread(conn, room):
    while True:
        try:
            msg = conn.recv(1024).decode().strip()
            username = chatrooms[room]['names'][conn]

            if msg.lower() == '/quit':
                # User exits voluntarily from the chat
                conn.send(b"Quitting chat...\n")
                conn.close()
                del chatrooms[room]['clients'][username]
                del chatrooms[room]['names'][conn]
                broadcast(room, f"{username} left the chat.\n")
                log_event(room, f"{username} left the chat.")
                break
            else:
                broadcast(room, msg, sender=username)
                log_event(room, f"{username}: {msg}")

        except:
            break

# Sends a message to all users in the room (except excluded ones)
def broadcast(room, msg, sender=None, exclude=[]):
    for user, client_conn in chatrooms[room]['clients'].items():
        if user in exclude:
            continue
        try:
            if sender is None:
                client_conn.send(msg.encode())
            elif user == sender:
                client_conn.send(f"you: {msg}\n".encode())
            else:
                client_conn.send(f"{sender}: {msg}\n".encode())
        except:
            continue

# Initializes the server socket and starts accepting connections
def start_server():
    # Use 0.0.0.0 to bind to all interfaces for LAN access
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(('0.0.0.0', 5555))  # Bind to all network interfaces
    server.listen(5)
    print("Server running on port 5555...")

    while True:
        conn, addr = server.accept()
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

start_server()
