import socket
import threading

PORT = 5555

# Ask the user for the server IP: Use '127.0.0.1' for local or a local IP for LAN
SERVER_IP = input("Enter server IP (127.0.0.1 for local or a local IP for LAN): ").strip()

# This function listens for messages from the server
def receive_messages(sock):
    while True:
        try:
            msg = sock.recv(1024).decode()
            if msg:
                print(msg, end='')
            else:
                break
        except:
            print("Connection closed by server.")
            break

# Create the socket and connect to the server
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((SERVER_IP, PORT))

# Start receiving messages in a separate thread
threading.Thread(target=receive_messages, args=(client,), daemon=True).start()

# Main loop to send messages to the server
while True:
    try:
        message = input()
        if message.lower() == '/quit':
            # Allow user to exit gracefully
            client.send(message.encode())
            break
        client.send(message.encode())
    except KeyboardInterrupt:
        print("\nDisconnected.")
        client.send(b"/quit")
        break
    except:
        break
